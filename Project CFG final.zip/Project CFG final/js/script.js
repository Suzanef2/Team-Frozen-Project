function initialcarousel(){
  const productContainers = [...document.querySelectorAll(".product-container")];
  const nxtBtn = [...document.querySelectorAll(".nxt-btn")];
  const preBtn = [...document.querySelectorAll(".pre-btn")];
  
  productContainers.forEach((item, i) => {
    let containerDimensions = item.getBoundingClientRect();
    let containerWidth = containerDimensions.width;
  
    nxtBtn[i].addEventListener("click", () => {
      item.scrollLeft += containerWidth;
    });
  
    preBtn[i].addEventListener("click", () => {
      item.scrollLeft -= containerWidth;
    });
  });
}


const route = (event) => {
  event = event || window.event;
  event.preventDefault();
  window.history.pushState({}, "", event.target.href);
  handleLocation();
};

const routes = {
  "/": "/pages/firstPage.html",
  "/travelguide": "/pages/travelguide.html",
  "/contact": "pages/contact-form.html",
};

const handleLocation = async () => {
  const path = window.location.pathname;
  const route = routes[path] || routes["/"];
  const html = await fetch(route).then((data) => data.text());
  document.getElementById("main-page").innerHTML = html;
  initialcarousel();
};

window.onpopstate = handleLocation;
window.route = route;

handleLocation();

function validForm() {
  alert("Thank you! We will contact you soon.");
}
